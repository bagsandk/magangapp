<div class="form-group">
    <input rows="3" type="text" class="form-control form-control-user" id="alamat" placeholder="Alamat">
</div>
<div class="form-group">
    <input type="text" class="form-control form-control-user" id="aasalptn" placeholder="Asal PTN">
</div>
<div class="form-group row">
    <div class="col-sm-6 mb-3 mb-sm-0">
        <input type="text" class="form-control form-control-user" id="npm" placeholder="NPM / NIM" name="npm">
    </div>
    <div class="custom-file col-sm-6 mb-sm-0">
        <input type="file" class=" custom-file-input" id="customFile">
        <label class="custom-file-label" for="customFile">Surat Tugas</label>
    </div>
</div>
<div class="form-group row">
    <div class="col-sm-6 mb-3 mb-sm-0">
        <select class="form-control form-control-select" id="exampleFormControlSelect1">
            <option value="" selected disabled>Jenis Kelamin</option>
            <option>Laki-laki</option>
            <option>Perempuan</option>
        </select>
    </div>
    <div class="col-sm-6">
        <select class="form-control  " id="exampleFormControlSelect1">
            <option value="" selected disabled>Agama</option>
            <option>Islam</option>
            <option>Hindu</option>
            <option>Kristen</option>
            <option>Budha</option>
            <option>Konguchu</option>
        </select>
    </div>
</div>